<article class="post-card">

    <div class="post-card__image">
        <div class="thumb-wide"></div>
    </div>


    <header class="entry-header">
        <div class="entry-title">Заголовок записи</div>
    </header><!-- .entry-header -->

    <div class="post-card__content" itemprop="articleBody">
        Небольшое описание или анонс записи, обычно генерируется автоматически.
    </div><!-- .entry-content -->

</article><!-- #post-## -->