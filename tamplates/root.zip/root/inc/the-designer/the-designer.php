<?php

class The_Designer {

    function __construct() {

    }

}